import React, {useState, useEffect} from 'react';
import {useAppTheme} from './ThemeContext';
import {useNavigate} from 'react-router-dom';
import axios from 'axios';

const BusinessProfile = () => {
    const {themeStyles} = useAppTheme();
    const navigate = useNavigate();
    const [hasBusiness, setHasBusiness] = useState(false);
    const [formData, setFormData] = useState({
        owner_email: localStorage.getItem('userEmail') || '',
        legal_name: '',
        gstin:'',
        home_state: 'MAHARASHTRA',
        turnover_category: 'REGULAR'
    });
    const [errorMessge, setErrorMessage] = useState('');
    const indianStates = [
        "ANDHRA PRADESH", "ARUNACHAL PRADESH","ASSAM","BIHAR","CHHATTISGARH",
        "GOA","GUJARAT","HARYANA","HIMACHAL PRADESH","JHARKHAND","KARNATAKA",
        "KERALA","MADHYA PRADESH","MAHARASHTRA","MANIPUR","MEGHALAYA","MIZORAM",
        "NAGALAND","ODISHA","PUNJAB","RAJASTHAN","SIKKIM","TAMIL NADU","TELANGANA",
        "TRIPURA","UTTAR PRADESH","UTTARAKHAND","WEST BENGAL","DELHI","LADAKH"
    ];
    const handleChange = (e) => {
        setFormData =({ ...formData, [e.target.name]: e.target.value.toUpperCase() });
    };
    const handleSubmit = async (e) =>{
        e.preventDefault();
        if (formData.gstin.length != 15) {
            setErrorMessage("Invalid GSTIN format! An Indian GSTIN must be exactly 15 characters long.");
            return;
        }
        try {
            const response = await axios.post('http://127.0.0',formData);
            if (response.data.success) {
                localStorage.setItem('activeBusinessId'.response.data.business_id);
                localStorage.setItem('businessHomeState',formData.home_state);
                navigate('/transaction-ledger');
            } else {
                setErrorMessage(response.data.error || "Failed to configure business profile.");
            }
        } catch (error) {
            setErrorMessage("Network connecting error occurred. Please try again.");
        }
    };
    return (
        <div style= {{padding: '40px', maxWidth:'500px',margin:'0 auto'}}>
            <h2 style = {{ color:themeStyles.primaryColor,textAlign:'center'}}>Configure Business Profile</h2>

            <form onSubmit = {handleSubmit} style={{display:'flex',flexDirection:'column',gap:'15px',marginTop:'20px'}}>
                <div>
                    <label style={{fontSize: '14px',fontWeight:'bold'}}>Owner Email Reference</label>
                    <input
                    type ="text" name="owner_email" readOnly
                    value = {formData.owner_email}
                    style = {{padding:'10px',width:'100%',boxSizing:'border-box',backgroundcolor:themeStyles.inputBackground,color:'#888',border:'1px solid ${themeStyles.borderColor}'}}
                    />
                </div>
                <div>
                    <label style={{fontSize:'14px', fontWeight:'bold'}}>Legal Business Name</label>
                    <input
                    type="text" name="legal_name" placeholder ="e.g sai trading business" required
                    value = {formData.legal_name}
                    style={{padding:'10px',width:'100%',boxSizing:'border-box',backgroundcolor:themeStyles.inputBackground,color:themeStyles.color,border:'1px solid ${themeStyles.borderColor}'}}
                    />
                </div>
                <div>
                    <label style={{fontSize:'14px',fontWeight:'bold'}}>15-Digit GSTIN Number</label>
                    <input
                    type="text" name="gstin" placeholder = "e.g, 27AAAAA1111A1Z1" required
                    vlue={formData.gstin}
                    style={{padding:'10px',width:'100%',boxSizing:'border-box',backgroundcolor:themeStylea.inputBackground,color:themeStyles.color,border:'1px solid ${themeStyles.borderColor'}}
                    />
                </div>
                <div>
                    <label style={{fontSize:'14px',fontWeight:'bold'}}>Primary Home State Operating Basea</label>
                    <select
                    name="home_state" value={formData.home_state} onChange={handleChange}
                    style={{padding:'10px',width:'100%',boxSizing:'border-box',backgroundcolor:themeStyles.inputBackground,color:themeStyles.color,border:'1px solid ${themeStyles.borderColor'}}
                    >
                        {indianStates.map((state) => (
                            <option key={state} value={state}>{state}</option>
                        ))}
                    </select>
                </div>
                <div>
                    <label style={{fontSize:'14px',fontWidth:'bold'}}>GST Filing Turnover Category</label>
                    <select
                    name="turnover_category" value={formData.turnover_category} onChange={handleChange}
                    style={{padding:'10px',width:'100%',boxSizing:'border-box',backgroundcolor:themeStyles.inputBackgfound,color:themeStyles.color,border:"1px solid ${themeStyles.borderColor"}}
                    >
                        <option value="REGULAR">REGULAR TAXPAYER SCHEME</option> 
                        <option value="COMPOSITION">COMPOSITION TAXPAYER SCHEME</option>
                    </select>
                </div>
                <button type="submit" style={{padding:'12px',backgroundcolor:themeStyles.primaryColor,color:'#fff',border:'none',cursor:'pointer',fontWeight:'bold',marginTop:'10px'}}>
                    Save & Initialize Workspace
                </button>
            </form>
            {errorMessage && <p style={{color:'red',marginTop:'15px',textAlign:'center',fontSize:'14px'}}>{errorMessage}</p>}
        </div>
    );
};