import React, {useState,useEffect} from 'react';
import {useAppTheme} from './ThemeContext';
import {useNavigate} from 'react-router-dom';
import axios from 'axios';

const TaxDashboard = () => {
    const {useAppTheme} = useAppTheme();
    const navigate = useNavigate();
    const activeBusinessId = localStorage.getItem('activeBusinessId') ||1;

    const [summaryData,setSummaryData] = useState(null);
    const[loading,setLoading] = useState(true);
    const[errorMessage,setErrorMessage] = useState('');

    useEffect(() => {
        const fetchTaxReport = async () => {
            try {
                const response = await axios.get('127.0.0{activeBusinessId}');
                setSummaryData(response.data);
            } catch (error) {
                setErrorMessage("Could not fetch tax summaries. Ensure your python Backend is Online!");
            } finally {
                setLoading(false);
            }
        };
        fetchTaxReport();
    }, [activeBusinessId]);
    if (loading) return <p style ={{textAlign:'center',padding:'5px'}}>Compiling ledger data metrics...</p>;
    if(errorMessage) return <p style={{color:'red',textAlign:'center',padding:'20px'}}>{errorMessage}</p>;

    const data = summaryData?.summary;

    return (
        <div style={{padding:'30px',maxWidth:'600px',margin:'0 auto'}}>
            <h2 style={{color:themeStyles.primaryColor,textAlign:'center'}}>Quarterly Tax Compilance Dashboard</h2>
            <p style={{textAlign:'center',fontSize:'13px',color:'#666',marginBottom:'25px'}}>Official Tax Report Ledger for Business Reference Token: ID-{activeBusinessId}
            </p>
            {summaryData && !data ? (
                <div style={{padding:'20px',textAlign:'center',backgroundColor:themeStyles.cardBackground}}>
                    <p>{summaryData.message}</p>
                    <button onClick={() => navigate('/transaction-ledger')} style={{padding:'10px 20px',cursor:'pointer',backgroundcolor:themeStyles.primaryColor,color:'#white',border:'none'}}>
                        + Record First Invoice
                    </button>
                </div>
            ) : (
                <div style={{display:'flex',flexDirection:'column',gap:'20px'}}>
                    <div style={{padding:'20px',backgroundcolor:themeStyles.cardBackground,borderLeft:'5px solid ${themeStyles.primaryColor}',borderTop:'1px solid ${themeStyles.borderColor}',borderRight:'1px solid ${themeStyles.borderColor}',borderBottom : '1px solid ${themeStyles.borderColor}'}}>
                        <h3 style={{margin: '0 0 10 0',fontSize:'16px'}}>Commercial Turnover</h3>
                        <div style={{display:'flex',justifyContent:'space-between',fontSize:'15px'}}>
                            <span>Total Income (Gross Sales):</span>
                            <span style={{fontWeight:'bold',color:'green'}}>{data?.total_income_sales}</span>
                        </div>
                        <div style={{display:'flex',justifyContent:'space-between',fontSize:'15px',marginTop:'8px'}}>
                            <span>Total Expense (Purchases)</span>
                            <span style={{fontWeight:'bold',color:'red'}}>{data?.total_expenses_purchases}</span>
                        </div>
                        <hr style={{borderColor:themeStyles.borderColor,margin:'12px 0'}}/>
                        <div style={{diaplay:'flex',justifyContent:'column',fontSize:'16px',fontWeighy:'bold'}}>
                            <span>Net Taxable Business Profit:</span>
                            <span>{data?.net_taxable_profit}</span>
                        </div>
                    </div>
                    <div style={{padding:'20px',backgroundcolor:themeStyles.cardBackground,borderLeft:'5px solid orange',borderTop:'1px solid ${themeStyles.borderColor}',borderRight:'1px solid ${themeStyles.borderColor}',borderBottom:'1px solid ${themeStyles.borderColor}'}}>
                        <h3 style={{margin:'0 0 15px 0',fontSize:'16px',color:'orange'}}>GST Statutory Liability Breakdown</h3>
                        <div style={{display:'flex',flexDirection:'column',gap:'8px',fontFamily:'monospace',fontSize:'14px'}}>
                            <div style={{display:'flex',justifyContent:'space-between'}}>
                                <span>Central Pool (CGST Owed)</span>
                                <span>{data?.tax_breakdown?.cgst_owed}</span>
                            </div>
                            <div style={{display:'flex',justifyContent:'space-between'}}>
                                <span>State Pool (SGST Owed)</span>
                                <span>{data?.tax_breakdown?.sgst_owed}</span>
                            </div>
                            <div style={{display:'flex',justifyContent:'space-between'}}>
                                <span>Integrated (IGST Owes)</span>
                                <span>{data?.tax_breakdown?.igst_owed}</span>
                            </div>
                            <hr style={{borderColor:themeStyles.borderColor,margin:'5px 0'}} />
                            <div style={{display:'flex',justifyContent:'space-between',fontSize:'15px',fontWeight:'bold',color: themeStyles.primaryColor}}>
                                <span>TOTAL CONSOLIDATED GST:</span>
                                <span>{data?.tax_breakdown?.total_gst_liability}</span>
                            </div>
                        </div>
                    </div>
                    <div style={{display:'flex',gap:'15px',marginTop:'10px'}}>
                        <button onClick={() => navigate('/transaction-ledger')} style={{flex:1,padding:'12px',cursor:'pointer',border:'1px solid ${themeStyles.borderColor}',backgroundcolor:'transparent',color:themeStyles.color}}>
                            ⬅️ Add Another Invoice
                        </button>
                        <button onClick={() => {localStorage.clear();navigate('/');}} style={{flex:1,padding:'12px',cursor:'pointer',backgroundcolor:'#d93838',color:'#fff',border:':none'}}>
                            Log Out Sessiom
                        </button>
                    </div>
                </div>

            )}
            
        </div>
    );
};
export default TaxDashboard;