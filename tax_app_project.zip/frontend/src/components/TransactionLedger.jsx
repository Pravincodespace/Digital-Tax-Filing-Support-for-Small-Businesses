import React, {useState} from 'react';
import {useAppTheme} from './ThemeContext';
import {useNavigate} from 'react-router-dom';
import axios from 'axios';

const TransactionLedger = () =>{
    const{themeStyles}= useAppTheme();
    const navigate = useNavigate();

    const activeBusinessId = localStorage.getItem('activateBusinessId') || 1;
    const  businessHomeState = localStorage.getItem('businessHomeState') || 'MAHARASHTRA';

    const [formData, setFormData] = useState({
        business_id: parseInt(activeBusinessId),
        transaction_type: 'INCOME',
        gross_amount:'',
        discount:'0',
        extra_charges:'0',
        gst_rate:'18',
        place_of_supply:businessHomeState
    });
    const [calcResult, setCalcResult]=useState(null);
    const [errorMessage,setErrorMessage]=useState('');

    const indianStates=[
        "ANDHRA PRADESH","ARUNACHAL PRADESH","ASSAM","BIHAR","CHHATTISGARH","GOA",
        "GUJARAT","HARYANA","HIMACHAL PRADESH","JHARKHAND","KARNATAKA","KERALA",
        "MADHYA PRADESH","MAHARASHTRA","MANIPUR","MEGHALAYA","MIZORAM","NAGALAND",
        "ODISHA","PUNJAB","RAJASTHAN","SIKKIM","TAMIL NADU","TELANGANA","TRIPURA",
        "UTTAR PRADESH","UTTARAKHAND","WEST BENGAL","DELHI","LADAKH","INTERNATIONAL"
    ];
    const handleChange = (e)=>{
        setFormData({...formData, [e.target.name]: e.target.value});
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        setErrorMessage('');
        setCalcResult(null);

        try {
            const response= await axios.post('http://127.0.0', {
                ...formData,
                gross_amount: parseFloat(formData.gross_amount),
                discount:parseFloat(formData.discount),
                extra_charges:parseFloat(formData.extra_charges),
                gst_rate:parseFloat(formData.gst_rate)
            });
            if(response.data.success) {
                setCalcResult(response.data);
            }
        } catch (error) {
            setErrorMessage(error.response?.data?.detail || "Calculation submission failed.");
        }
    };
    return (
        <div style={{padding:'30px',maxWidth:'600px',margin:'0 auto'}}>
            <h2 style={{color:themeStyles.primaryColor,textAlign:'center'}}>Record Financial Invoice</h2>
            <p style={{textAlign:'center',fontSize:'14px',color:'#666'}}>Managing Business ID Reference: {activeBusinessId}</p>

            <form onSubmit={handleSubmit} style={{ display:'flex',flexDirection:'column', gap:'15px',marginTop:'20px'}}>
                <div style={{ display:'flex',gap:'15px'}}>
                    <div style={{flex:1}}>
                        <label style={{fontSize:'13px',fontWeight:'bold'}}>Transaction Nature</label>
                        <select name="transaction_type" value={formData.transaction_type} onChange={handleChange} style={{padding:'10px',width:'100%',backgroundcolor:themeStyles.inputBackground,color:themeStyles.color,border:'1px solid ${themeStyles.borderColor}'}}>
                            <option value="INCOME">INCONE (Customer Sales Biling)</option>
                            <option value="EXPENSE">EXPENSE (Vendor Purchase Log)</option>
                        </select>
                    </div>
                    <div style={{flex:1}}>
                        <label style={{fontSize:'13px',fontWeight:'bold'}}>Place of Supply (pos Target)</label>
                        <select name="place_of_supply" value={formData.place_of_supply} onChange={handleChange} style={{padding:'10px',width:'100%',backgroundcolor:themeStyles.inputBackground,color:themeStyles.color,border:'1px solid $(themeStyles.borderColor}'}}>
                            {indianStates.map((st) => <option key={st} value={st}>{st}</option>)}
                        </select>
                    </div>
                </div>
                <div>
                    <label style={{fontSize:'13px',fontWeight:'bold'}}>Gross Transaction Amount ()</label>
                    <input type="number" name="gross_amount" required placeholder="0.00" value={formData.gross_amount} onChange={handleChange} style={{padding:'10px',width:'100%',boxSizing:'border-box',backgroundcolor:themeStyles.inputBackground,color:themeStyles.color,border:'1px solid ${themeStyes.borderColor}'}}/>
                </div>
                <div style={{display:'flex',gap:'15px'}}>
                    <div style={{flex:1}}>
                        <label style={{fontSize:'13px',fontWeight:'bold'}}>Discount Applied ()</label>
                        <input type="number" name="discount" value={formData.discount} onChange={handleChange} style={{padding:'10px', width:'100%',boxSizing:'border-box',backgroundcolor:themeStyles.inputBackground,color:themeStyles.color,border:'1px solid ${themeStyles.borderColor}'}} />
                    </div>
                    <div style={{flex:1}}>
                        <label style={{fontSize:'13px',fontWeight:'bold'}}>Extra Charges/Freight ()</label>
                        <input type="number" name="extra_charges" value={formData.extra_charges} onChange={handleChange} style={{padding:'10px',width:'100%',boxSizing:'border-box',backgroundcolor:themeStyles.inputBackgroud,color:themeStyles.color,border:'1px solid ${themeStyles.borderColor}'}}/>
                    </div>
                </div>
                <div>
                    <label style={{fontSize:'13px',fontWeight:'bold'}}>Legal GST Tax Slab Percentage</label>
                    <select name="gst_rate" value={formData.gst_rate} onChange={handleChange} style={{padding:'10px',width:'100%',backgroundcolor:themeStyles.inputBackground,color:themeStyles.color,border:'1px solid ${themeStyles.borderColor}'}}>
                        <option value="0">0% Slab (Exempt Goods)</option>
                        <option value="5">5% Slab (Essentials)</option>
                        <option value="12">12% Slab (Standard Economy)</option>
                        <option value="18">18% Slab (Standard Tech/Services)</option>
                        <option value="28">28% Slab (Luxury Items)</option>
                    </select>
                </div>
                <button type="submit" style={{padding:'12px',backgroundcolor:themeStyles.primaryColor,color:'#fff',border:'none',cursor:'pointer',fontWeight:'bold'}}>
                    Compute Tax And Save Invoice Line
                </button>
            </form>
            {errorMessage && <p style={{color:'red',marginTop:'15px',textAlign:'center'}}>{errorMessage}</p>}
            {calcResult && (
                <div style={{marginTop:'25px',padding:'15px',backgroundcolor:themeStyles.cardBackground,border:'1px solid ${themeStyles.borderColor}'}}>
                    <h4 style={{color:'green',margin:'0 0 10px 0',}}>Invoice Loged Cleanly!</h4>
                    <p style={{fontSize:'13px',fontStyle:'italic',color:'#666'}}>{calcResult.summary}</p>
                    <hr style={{borderColor:themeStyles.borderColor}}/>
                    <div style={{diaplay:'flex',flexDirection:'column',gap:'5px',fontSize:'14px',fontFamily:'monospace',marginTop:'10px'}}>
                        <div>Base Taxable Value: {calcResult.calculations?.taxable_value}</div>
                        <div>Central Tax(CGST): {calcResult.calculations?.cgst_amount}</div>
                        <div>State Tax(SGST): {calcResult.calculations?.sgst_amount}</div>
                        <div>Border Tax(IGST)N {calcResult.calculations?.igst_amount}</div>
                        <div style={{fontWeight:'bold',color:themeStyles.primaryColor}}>Grand Total Bill : {calcResult.calculations?.grand_total}</div>
                    </div>
                    <button onClick={() => navigate('/tax-summary')} style={{marginTop:'15px',width:'100%',padding:'10px',cursor:'pointer'}}>
                        Full View Quater Tax Report ➡️
                    </button>
                </div>
            )}
        </div>
    );
};
export default TransactionLedger;