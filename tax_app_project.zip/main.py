from fastapi import FastAPI,HTTPException , Depends
from pydantic import BaseModel, field_validator
from enum import Enum
from auth_utils import hash_password, verify_password, create_access_token
from sqlalchemy.orm import Session
from database import engine, Base, get_db
from models import UserModel, BusinessModel, TransactionModel

INDIA_STATE_REGISTRY = {
    "JAMMU AND KASHMIR":"01","HIMACHAL PRADESH":"02","PUNJAB":"03","CHANDIGARH":"04",
    "UTTARAKHAND":"05", "HARYANA":"06","DELHI":"07","RAJASTHAN":"08","UTTAR PRADESH":"09",
    "BIHAR":"10","SIKKIM":"11","ARUNACHAL PRADESH":"12","ASSAM":"18","WEST BENGAL":"19",
    "JHARKHAD":"20","ODISHA":"21","CHHATTISHGARH":"22","MADHYA PRADESH":"23","GUJARAT":"24",
    "DAMAN AND DIU":"25","DADRA AND NAGAR HAVELI":"26","MAHARASHTRA":"27","ARUNACHAL PRADESH":"28",
    "KARNATAKA":"29","GOA":"30","LAKSHADWEEP":"31","KERALA":"32","TAMIL NADU":"33",
    "PUDUCHERRY":"34","ANDAMAN AND NICOBAR ISLANDS":"35","TELANGANA":"36","ANDHRA PRADESH (NEW)":"37",
    "LADAKH":"38"
}

def normalize_and_state_code(state_input: str)-> str:
    clean_input = state_input.strip().upper()
    if "-" in clean_input:
        parts = clean_input.split("-")
        potential_code = parts[0].strip()
        if potential_code.isdigit() and len(potential_code) == 2:
            return potential_code

    if clean_input in INDIA_STATE_REGISTRY:
        return INDIA_STATE_REGISTRY[clean_input]

    if clean_input == "INTERNATIONAL":
        return "INT"

    return "UNKNOWN"

Base.metadata.create_all(bind = engine)

app=FastAPI(title="Digital Tax Filing support App")

class UserSignup(BaseModel):
    full_name:str
    email:str
    password:str

class UserLogin(BaseModel):
    email:str
    password:str

@app.get("/")
def home():
    return{"status":"Online","message":"Welcome To Your Digital Tax Filing Backend"}

@app.post("/register")
def register_user(user: UserSignup, db: Session = Depends(get_db)):
    existing = db.query(UserModel).filter(UserModel.email == user.email).first()
    if existing:
        raise HTTPException(status_code=400,detail="Email already registered!")
    hashed = hash_password(user.password)
    db_user = UserModel(full_name = user.full_name, email = user.email, password_hash = hashed)
    db.add(db_user)
    db.commit()

    return {
        "success":True,
        "message":f"Account Successfully Created For {user.full_name}!"

    }
@app.post("/login")
def Login_User(user: UserLogin, db: Session = Depends(get_db)):
    db_user = db.query(UserModel).filter(UserModel.email == user.email).first()
    if not db_user or not verify_password(user.password, db_user.password_hash):
        raise HTTPException(status_code=400,detail="Invalid Email or Password!")

    token=create_access_token(user_email=user.email)
    return {
        "login_status":"success",
        "access_token":token,
        "token_type":"bearer"
    }

class RegimeEnum(str,Enum):
    regular="REGULAR"
    compositiom="COMPOSITION"

class BusinessCreate(BaseModel):
    owner_email:str
    legal_name:str
    gstin:str
    home_state:str
    turnover_category:RegimeEnum

@app.post("/create-business")
def create_business(business:BusinessCreate, db: Session = Depends(get_db)):
    if len(business.gstin)!=15:
        return {"success":False,"error":"Invalid GSTIN! An Indian GSTIN must be exactly 15 characters long."}
        
    db_business = BusinessModel(
        owner_email = business.owner_email,
        legal_name = business.legal_name,
        gstin = business.gstin,
        home_state = business.home_state,
        turnover_category = business.turnover_category.value
    )
    db.add(db_business)
    db.commit()

    return{
        "success":True,
        "message":f"Business '{business.legal_name}' saved to local database.",
        "business_id":db_business.id
    }

class ScopeEnum(str,Enum):
    intrastate="INTRASTATE"
    interstate="INTERSTATE"
    international="INTERNATIONAL"

class TypeEnum(str,Enum):
    income="INCOME"
    expense="EXPENSE"


class TransactionInput(BaseModel):
    business_id:int
    transaction_type:TypeEnum
    gross_amount:float
    discount:float=0.0
    extra_charges:float=0.0
    gst_rate:float
    place_of_supply: str

    @field_validator('gst_rate')
    def validte_indian_tax_slabs(cls,value):
        legal_slabs=[0.0,5.0,12.0,18.0,28.0]
        if value not in legal_slabs:
            raise ValueError(f"Invalid GST Slab! You entered {value}%. Indian GST allows only 0%,5%,18%, or 28%.")
        return value

@app.post("/add-transaction-v2")
def add_transaction_v2(item: TransactionInput, db: Session = Depends(get_db)):
    biz = db.query(BusinessModel).filter(BusinessModel.id == item.business_id).first()
    business_home_code = normalize_and_state_code(biz.home_state)
    transaction_pos_code = normalize_and_state_code(item.place_of_supply)
    if not biz:
        raise HTTPException(status_code = 404, detail = "Business profile not found!")
    taxable_value = item.gross_amount - item.discount + item.extra_charges
    cgst,sgst,igst=0.0,0.0,0.0
    scope_result = ""

    if transaction_pos_code == "INT":
        scope_result = "INTERNATIONAL"
        if item.transaction_type == TypeEnum.income:
            summary = "International Export. Zero rated supply."
        else:
            igst = taxable_value*(item.gst_rate/100)
            summary = "International Import. 100% IGST under RCM."

    elif transaction_pos_code == business_home_code:
        scope_result = "INTRASTATE"
        total_gst=taxable_value*(item.gst_rate/100)
        cgst=total_gst/2
        sgst=total_gst/2
        summary="Local traade within {biz.home_state}. Split into CGST and SGST."
    else:
        scope_result = "INTERSTATE"
        igst=taxable_value*(item.gst_rate/100)
        summary="Interstate transaction"

    db_tx = TransactionModel(
        business_id = item.business_id, transaction_type = item.transaction_type.value,
        gross_amount = item.gross_amount, discount = item.discount, extra_charges = item.extra_charges,
        gst_rate = item.gst_rate, place_of_supply = item.place_of_supply, calculated_scope = scope_result,
        taxable_value = taxable_value, cgst_amount = round(cgst,2), sgst_amount = round(sgst,2),
        igst_amount = round(igst,2), total_tax = round(cgst + sgst + igst,2), grand_total = round(taxable_value+cgst+sgst+igst,2)
    )
    db.add(db_tx)
    db.commit()
    return{"success":True, "summary": summary, "transaction_id":db_tx.id}

PRODUCT_CATALOG={
    "laptop":{"hsn":"8471","gst_rate":18.0},
    "smartphone":{"hsn":"8517","gst_rate":18.0},
    "packaged_food":{"hsn":"2106","gst_rate":5.0},
    "milk":{"hsn":"0401","gst_rate":0.0},
    "software_service":{"hsn":"9983","gst_rate":18.0}
}
@app.get("/autofill-item")    
def autofill_item(product_name:str):
    query=product_name.lower().strip()
    if query in PRODUCT_CATALOG:
        return{
            "found":True,
            "product":product_name,
            "hsn_code":PRODUCT_CATALOG[query]["hsn"],
            "auto_gst_rate":PRODUCT_CATALOG[query]["gst_rate"]
        }
    else:
        return{
            "found":False,
            "message":"Product not in default catalog. Please enter tax rate manually.",
            "auto_gst_rate":18.0
        }

@app.get("/tax-summary")
def get_tax_summary(business_id: int, db: Session = Depends(get_db)):
    business_txs= db.query(TransactionModel).filter(TransactionModel.business_id == business_id).all()

    if not business_txs:
        return {
            "message":"No transaction found for this business yet.",
            "total_tax_owed":0.0
        }
    total_income=0.0
    total_expanse=0.0
    total_cgst=0.0
    total_sgst=0.0
    total_igst=0.0

    for tx in business_txs:
        val = tx.taxable_value

        if tx.transaction_type == "INCOME":
            total_income += val
            total_cgst += tx.cgst_amount
            total_sgst += tx.sgst_amount
            total_igst += tx.igst_amount
        else:
            total_expanse += val

    net_profit = total_income - total_expanse
    total_gst_pool = total_cgst + total_sgst + total_igst
    return {
        "success":True,
        "business_id":business_id,
        "summary": {
            "total_income_sales": round(total_income,2),
            "total_expanse_purchases": round(total_expanse,2),
            "net_taxable_profit": round(net_profit,2),
            "tax_breakdown":{
                "cgst_owed": round(total_cgst,2),
                "sgst_owed": round(total_sgst,2),
                "igst_owed": round(total_igst,2),
                "total_gst_liability": round(total_gst_pool,2)
            }

        }
    }